/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import pml.PmlFactory;
import pml.ULA;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>ULA</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ULATest extends TestCase {

	/**
	 * The fixture for this ULA test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ULA fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ULATest.class);
	}

	/**
	 * Constructs a new ULA test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ULATest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this ULA test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(ULA fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this ULA test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ULA getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(PmlFactory.eINSTANCE.createULA());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ULATest
