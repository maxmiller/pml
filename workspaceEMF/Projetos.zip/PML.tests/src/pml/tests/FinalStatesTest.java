/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import pml.FinalStates;
import pml.PmlFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Final States</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class FinalStatesTest extends TestCase {

	/**
	 * The fixture for this Final States test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FinalStates fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(FinalStatesTest.class);
	}

	/**
	 * Constructs a new Final States test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FinalStatesTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Final States test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(FinalStates fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Final States test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FinalStates getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(PmlFactory.eINSTANCE.createFinalStates());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //FinalStatesTest
