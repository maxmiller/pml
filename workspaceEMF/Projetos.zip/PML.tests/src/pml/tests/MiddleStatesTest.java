/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import pml.MiddleStates;
import pml.PmlFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Middle States</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class MiddleStatesTest extends TestCase {

	/**
	 * The fixture for this Middle States test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MiddleStates fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(MiddleStatesTest.class);
	}

	/**
	 * Constructs a new Middle States test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MiddleStatesTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Middle States test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(MiddleStates fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Middle States test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MiddleStates getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(PmlFactory.eINSTANCE.createMiddleStates());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //MiddleStatesTest
