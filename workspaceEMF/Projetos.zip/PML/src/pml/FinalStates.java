/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Final States</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pml.PmlPackage#getFinalStates()
 * @model
 * @generated
 */
public interface FinalStates extends EObject {
} // FinalStates
