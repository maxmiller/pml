/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import pml.MicroInstruction;
import pml.PmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Micro Instruction</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link pml.impl.MicroInstructionImpl#getName <em>Name</em>}</li>
 *   <li>{@link pml.impl.MicroInstructionImpl#getValue <em>Value</em>}</li>
 *   <li>{@link pml.impl.MicroInstructionImpl#getNextMicroStruction <em>Next Micro Struction</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MicroInstructionImpl extends EObjectImpl implements MicroInstruction {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final int VALUE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected int value = VALUE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getNextMicroStruction() <em>Next Micro Struction</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextMicroStruction()
	 * @generated
	 * @ordered
	 */
	protected MicroInstruction nextMicroStruction;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MicroInstructionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PmlPackage.Literals.MICRO_INSTRUCTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.MICRO_INSTRUCTION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(int newValue) {
		int oldValue = value;
		value = newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.MICRO_INSTRUCTION__VALUE, oldValue, value));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroInstruction getNextMicroStruction() {
		return nextMicroStruction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNextMicroStruction(MicroInstruction newNextMicroStruction, NotificationChain msgs) {
		MicroInstruction oldNextMicroStruction = nextMicroStruction;
		nextMicroStruction = newNextMicroStruction;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION, oldNextMicroStruction, newNextMicroStruction);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNextMicroStruction(MicroInstruction newNextMicroStruction) {
		if (newNextMicroStruction != nextMicroStruction) {
			NotificationChain msgs = null;
			if (nextMicroStruction != null)
				msgs = ((InternalEObject)nextMicroStruction).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION, null, msgs);
			if (newNextMicroStruction != null)
				msgs = ((InternalEObject)newNextMicroStruction).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION, null, msgs);
			msgs = basicSetNextMicroStruction(newNextMicroStruction, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION, newNextMicroStruction, newNextMicroStruction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION:
				return basicSetNextMicroStruction(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PmlPackage.MICRO_INSTRUCTION__NAME:
				return getName();
			case PmlPackage.MICRO_INSTRUCTION__VALUE:
				return getValue();
			case PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION:
				return getNextMicroStruction();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PmlPackage.MICRO_INSTRUCTION__NAME:
				setName((String)newValue);
				return;
			case PmlPackage.MICRO_INSTRUCTION__VALUE:
				setValue((Integer)newValue);
				return;
			case PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION:
				setNextMicroStruction((MicroInstruction)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PmlPackage.MICRO_INSTRUCTION__NAME:
				setName(NAME_EDEFAULT);
				return;
			case PmlPackage.MICRO_INSTRUCTION__VALUE:
				setValue(VALUE_EDEFAULT);
				return;
			case PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION:
				setNextMicroStruction((MicroInstruction)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PmlPackage.MICRO_INSTRUCTION__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case PmlPackage.MICRO_INSTRUCTION__VALUE:
				return value != VALUE_EDEFAULT;
			case PmlPackage.MICRO_INSTRUCTION__NEXT_MICRO_STRUCTION:
				return nextMicroStruction != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", value: ");
		result.append(value);
		result.append(')');
		return result.toString();
	}

} //MicroInstructionImpl
