/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import pml.MiddleStates;
import pml.PmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Middle States</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class MiddleStatesImpl extends EObjectImpl implements MiddleStates {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MiddleStatesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PmlPackage.Literals.MIDDLE_STATES;
	}

} //MiddleStatesImpl
