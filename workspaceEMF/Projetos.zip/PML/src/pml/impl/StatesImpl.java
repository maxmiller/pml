/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pml.FinalStates;
import pml.InitialStates;
import pml.MiddleStates;
import pml.PmlPackage;
import pml.States;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>States</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link pml.impl.StatesImpl#getIState <em>IState</em>}</li>
 *   <li>{@link pml.impl.StatesImpl#getFState <em>FState</em>}</li>
 *   <li>{@link pml.impl.StatesImpl#getMStates <em>MStates</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StatesImpl extends EObjectImpl implements States {
	/**
	 * The cached value of the '{@link #getIState() <em>IState</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIState()
	 * @generated
	 * @ordered
	 */
	protected InitialStates iState;

	/**
	 * The cached value of the '{@link #getFState() <em>FState</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFState()
	 * @generated
	 * @ordered
	 */
	protected FinalStates fState;

	/**
	 * The cached value of the '{@link #getMStates() <em>MStates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMStates()
	 * @generated
	 * @ordered
	 */
	protected EList<MiddleStates> mStates;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StatesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PmlPackage.Literals.STATES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InitialStates getIState() {
		return iState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIState(InitialStates newIState, NotificationChain msgs) {
		InitialStates oldIState = iState;
		iState = newIState;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PmlPackage.STATES__ISTATE, oldIState, newIState);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIState(InitialStates newIState) {
		if (newIState != iState) {
			NotificationChain msgs = null;
			if (iState != null)
				msgs = ((InternalEObject)iState).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PmlPackage.STATES__ISTATE, null, msgs);
			if (newIState != null)
				msgs = ((InternalEObject)newIState).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PmlPackage.STATES__ISTATE, null, msgs);
			msgs = basicSetIState(newIState, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.STATES__ISTATE, newIState, newIState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FinalStates getFState() {
		return fState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFState(FinalStates newFState, NotificationChain msgs) {
		FinalStates oldFState = fState;
		fState = newFState;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PmlPackage.STATES__FSTATE, oldFState, newFState);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFState(FinalStates newFState) {
		if (newFState != fState) {
			NotificationChain msgs = null;
			if (fState != null)
				msgs = ((InternalEObject)fState).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PmlPackage.STATES__FSTATE, null, msgs);
			if (newFState != null)
				msgs = ((InternalEObject)newFState).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PmlPackage.STATES__FSTATE, null, msgs);
			msgs = basicSetFState(newFState, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.STATES__FSTATE, newFState, newFState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MiddleStates> getMStates() {
		if (mStates == null) {
			mStates = new EObjectContainmentEList<MiddleStates>(MiddleStates.class, this, PmlPackage.STATES__MSTATES);
		}
		return mStates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PmlPackage.STATES__ISTATE:
				return basicSetIState(null, msgs);
			case PmlPackage.STATES__FSTATE:
				return basicSetFState(null, msgs);
			case PmlPackage.STATES__MSTATES:
				return ((InternalEList<?>)getMStates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PmlPackage.STATES__ISTATE:
				return getIState();
			case PmlPackage.STATES__FSTATE:
				return getFState();
			case PmlPackage.STATES__MSTATES:
				return getMStates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PmlPackage.STATES__ISTATE:
				setIState((InitialStates)newValue);
				return;
			case PmlPackage.STATES__FSTATE:
				setFState((FinalStates)newValue);
				return;
			case PmlPackage.STATES__MSTATES:
				getMStates().clear();
				getMStates().addAll((Collection<? extends MiddleStates>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PmlPackage.STATES__ISTATE:
				setIState((InitialStates)null);
				return;
			case PmlPackage.STATES__FSTATE:
				setFState((FinalStates)null);
				return;
			case PmlPackage.STATES__MSTATES:
				getMStates().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PmlPackage.STATES__ISTATE:
				return iState != null;
			case PmlPackage.STATES__FSTATE:
				return fState != null;
			case PmlPackage.STATES__MSTATES:
				return mStates != null && !mStates.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //StatesImpl
