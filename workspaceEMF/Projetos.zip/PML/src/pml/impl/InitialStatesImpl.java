/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import pml.InitialStates;
import pml.PmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Initial States</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class InitialStatesImpl extends EObjectImpl implements InitialStates {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InitialStatesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PmlPackage.Literals.INITIAL_STATES;
	}

} //InitialStatesImpl
