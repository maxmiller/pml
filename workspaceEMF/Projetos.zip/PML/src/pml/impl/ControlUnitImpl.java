/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package pml.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pml.Behavior;
import pml.ControlUnit;
import pml.Input;
import pml.Instructions;
import pml.Operation;
import pml.Output;
import pml.PmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Control Unit</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link pml.impl.ControlUnitImpl#getBehaviorsControlUnit <em>Behaviors Control Unit</em>}</li>
 *   <li>{@link pml.impl.ControlUnitImpl#getInputsControlUnit <em>Inputs Control Unit</em>}</li>
 *   <li>{@link pml.impl.ControlUnitImpl#getOutputsControlUnit <em>Outputs Control Unit</em>}</li>
 *   <li>{@link pml.impl.ControlUnitImpl#getName <em>Name</em>}</li>
 *   <li>{@link pml.impl.ControlUnitImpl#getControlUnitOperation <em>Control Unit Operation</em>}</li>
 *   <li>{@link pml.impl.ControlUnitImpl#getEReference0 <em>EReference0</em>}</li>
 *   <li>{@link pml.impl.ControlUnitImpl#getIntructions <em>Intructions</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ControlUnitImpl extends EObjectImpl implements ControlUnit {
	/**
	 * The cached value of the '{@link #getBehaviorsControlUnit() <em>Behaviors Control Unit</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBehaviorsControlUnit()
	 * @generated
	 * @ordered
	 */
	protected EList<Behavior> behaviorsControlUnit;

	/**
	 * The cached value of the '{@link #getInputsControlUnit() <em>Inputs Control Unit</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputsControlUnit()
	 * @generated
	 * @ordered
	 */
	protected EList<Input> inputsControlUnit;

	/**
	 * The cached value of the '{@link #getOutputsControlUnit() <em>Outputs Control Unit</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputsControlUnit()
	 * @generated
	 * @ordered
	 */
	protected EList<Output> outputsControlUnit;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getControlUnitOperation() <em>Control Unit Operation</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlUnitOperation()
	 * @generated
	 * @ordered
	 */
	protected Operation controlUnitOperation;

	/**
	 * The cached value of the '{@link #getEReference0() <em>EReference0</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEReference0()
	 * @generated
	 * @ordered
	 */
	protected ControlUnit eReference0;

	/**
	 * The cached value of the '{@link #getIntructions() <em>Intructions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIntructions()
	 * @generated
	 * @ordered
	 */
	protected EList<Instructions> intructions;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ControlUnitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PmlPackage.Literals.CONTROL_UNIT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Behavior> getBehaviorsControlUnit() {
		if (behaviorsControlUnit == null) {
			behaviorsControlUnit = new EObjectContainmentEList<Behavior>(Behavior.class, this, PmlPackage.CONTROL_UNIT__BEHAVIORS_CONTROL_UNIT);
		}
		return behaviorsControlUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Input> getInputsControlUnit() {
		if (inputsControlUnit == null) {
			inputsControlUnit = new EObjectContainmentEList<Input>(Input.class, this, PmlPackage.CONTROL_UNIT__INPUTS_CONTROL_UNIT);
		}
		return inputsControlUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Output> getOutputsControlUnit() {
		if (outputsControlUnit == null) {
			outputsControlUnit = new EObjectContainmentEList<Output>(Output.class, this, PmlPackage.CONTROL_UNIT__OUTPUTS_CONTROL_UNIT);
		}
		return outputsControlUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.CONTROL_UNIT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Operation getControlUnitOperation() {
		return controlUnitOperation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetControlUnitOperation(Operation newControlUnitOperation, NotificationChain msgs) {
		Operation oldControlUnitOperation = controlUnitOperation;
		controlUnitOperation = newControlUnitOperation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION, oldControlUnitOperation, newControlUnitOperation);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setControlUnitOperation(Operation newControlUnitOperation) {
		if (newControlUnitOperation != controlUnitOperation) {
			NotificationChain msgs = null;
			if (controlUnitOperation != null)
				msgs = ((InternalEObject)controlUnitOperation).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION, null, msgs);
			if (newControlUnitOperation != null)
				msgs = ((InternalEObject)newControlUnitOperation).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION, null, msgs);
			msgs = basicSetControlUnitOperation(newControlUnitOperation, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION, newControlUnitOperation, newControlUnitOperation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControlUnit getEReference0() {
		if (eReference0 != null && eReference0.eIsProxy()) {
			InternalEObject oldEReference0 = (InternalEObject)eReference0;
			eReference0 = (ControlUnit)eResolveProxy(oldEReference0);
			if (eReference0 != oldEReference0) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PmlPackage.CONTROL_UNIT__EREFERENCE0, oldEReference0, eReference0));
			}
		}
		return eReference0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControlUnit basicGetEReference0() {
		return eReference0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEReference0(ControlUnit newEReference0) {
		ControlUnit oldEReference0 = eReference0;
		eReference0 = newEReference0;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PmlPackage.CONTROL_UNIT__EREFERENCE0, oldEReference0, eReference0));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Instructions> getIntructions() {
		if (intructions == null) {
			intructions = new EObjectContainmentEList<Instructions>(Instructions.class, this, PmlPackage.CONTROL_UNIT__INTRUCTIONS);
		}
		return intructions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PmlPackage.CONTROL_UNIT__BEHAVIORS_CONTROL_UNIT:
				return ((InternalEList<?>)getBehaviorsControlUnit()).basicRemove(otherEnd, msgs);
			case PmlPackage.CONTROL_UNIT__INPUTS_CONTROL_UNIT:
				return ((InternalEList<?>)getInputsControlUnit()).basicRemove(otherEnd, msgs);
			case PmlPackage.CONTROL_UNIT__OUTPUTS_CONTROL_UNIT:
				return ((InternalEList<?>)getOutputsControlUnit()).basicRemove(otherEnd, msgs);
			case PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION:
				return basicSetControlUnitOperation(null, msgs);
			case PmlPackage.CONTROL_UNIT__INTRUCTIONS:
				return ((InternalEList<?>)getIntructions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PmlPackage.CONTROL_UNIT__BEHAVIORS_CONTROL_UNIT:
				return getBehaviorsControlUnit();
			case PmlPackage.CONTROL_UNIT__INPUTS_CONTROL_UNIT:
				return getInputsControlUnit();
			case PmlPackage.CONTROL_UNIT__OUTPUTS_CONTROL_UNIT:
				return getOutputsControlUnit();
			case PmlPackage.CONTROL_UNIT__NAME:
				return getName();
			case PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION:
				return getControlUnitOperation();
			case PmlPackage.CONTROL_UNIT__EREFERENCE0:
				if (resolve) return getEReference0();
				return basicGetEReference0();
			case PmlPackage.CONTROL_UNIT__INTRUCTIONS:
				return getIntructions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PmlPackage.CONTROL_UNIT__BEHAVIORS_CONTROL_UNIT:
				getBehaviorsControlUnit().clear();
				getBehaviorsControlUnit().addAll((Collection<? extends Behavior>)newValue);
				return;
			case PmlPackage.CONTROL_UNIT__INPUTS_CONTROL_UNIT:
				getInputsControlUnit().clear();
				getInputsControlUnit().addAll((Collection<? extends Input>)newValue);
				return;
			case PmlPackage.CONTROL_UNIT__OUTPUTS_CONTROL_UNIT:
				getOutputsControlUnit().clear();
				getOutputsControlUnit().addAll((Collection<? extends Output>)newValue);
				return;
			case PmlPackage.CONTROL_UNIT__NAME:
				setName((String)newValue);
				return;
			case PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION:
				setControlUnitOperation((Operation)newValue);
				return;
			case PmlPackage.CONTROL_UNIT__EREFERENCE0:
				setEReference0((ControlUnit)newValue);
				return;
			case PmlPackage.CONTROL_UNIT__INTRUCTIONS:
				getIntructions().clear();
				getIntructions().addAll((Collection<? extends Instructions>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PmlPackage.CONTROL_UNIT__BEHAVIORS_CONTROL_UNIT:
				getBehaviorsControlUnit().clear();
				return;
			case PmlPackage.CONTROL_UNIT__INPUTS_CONTROL_UNIT:
				getInputsControlUnit().clear();
				return;
			case PmlPackage.CONTROL_UNIT__OUTPUTS_CONTROL_UNIT:
				getOutputsControlUnit().clear();
				return;
			case PmlPackage.CONTROL_UNIT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION:
				setControlUnitOperation((Operation)null);
				return;
			case PmlPackage.CONTROL_UNIT__EREFERENCE0:
				setEReference0((ControlUnit)null);
				return;
			case PmlPackage.CONTROL_UNIT__INTRUCTIONS:
				getIntructions().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PmlPackage.CONTROL_UNIT__BEHAVIORS_CONTROL_UNIT:
				return behaviorsControlUnit != null && !behaviorsControlUnit.isEmpty();
			case PmlPackage.CONTROL_UNIT__INPUTS_CONTROL_UNIT:
				return inputsControlUnit != null && !inputsControlUnit.isEmpty();
			case PmlPackage.CONTROL_UNIT__OUTPUTS_CONTROL_UNIT:
				return outputsControlUnit != null && !outputsControlUnit.isEmpty();
			case PmlPackage.CONTROL_UNIT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case PmlPackage.CONTROL_UNIT__CONTROL_UNIT_OPERATION:
				return controlUnitOperation != null;
			case PmlPackage.CONTROL_UNIT__EREFERENCE0:
				return eReference0 != null;
			case PmlPackage.CONTROL_UNIT__INTRUCTIONS:
				return intructions != null && !intructions.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ControlUnitImpl
